import Dao.StudentDAO;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;

import java.io.IOException;

@WebServlet("/signup")
public class StudentSignupServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get form data
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String dateOfBirth = request.getParameter("dateOfBirth");


        Student student = new Student(firstName, lastName, dateOfBirth);


        StudentDAO studentDAO = new YourStudentDAOImplementation();
        studentDAO.insertStudent(student);


        response.sendRedirect("/success");
    }
}
