package web.servlet;

public enum DepartmentType {
    NETWORKING, SOFTWARE_ENGINEERING, INFORMATION_MANAGEMENT
}
