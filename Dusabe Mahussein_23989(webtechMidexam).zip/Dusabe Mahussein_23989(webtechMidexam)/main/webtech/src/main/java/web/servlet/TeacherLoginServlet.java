import java.io.IOException;
import java.io.PrintWriter;
import java.util.Optional;


// Replace with your actual teacher DAO implementation
import Dao.TeacherDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/login_handler")
public class TeacherLoginServlet extends HttpServlet {

    private TeacherDAO teacherDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        // Replace with your actual teacherDAO initialization logic
        teacherDAO = // Your teacherDAO initialization logic;
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");


        if (username == null || username.isEmpty() || password == null || password.isEmpty()) {
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<html><body>Please enter username and password!</body></html>");
            return;
        }


        Optional<Teacher> optionalTeacher = teacherDAO.findStudentById(username);

        // Check if teacher exists and password matches
        if (optionalTeacher.isPresent() && optionalTeacher.get().getPassword().equals(password)) {
            Teacher teacher = optionalTeacher.get();


            HttpSession session = request.getSession(true);
            session.setAttribute("teacher", teacher);


            response.sendRedirect("teacher_dashboard.jsp");
        } else {
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<html><body>Invalid username or password!</body></html>");
        }
    }
}
