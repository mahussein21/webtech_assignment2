package web.servlet;

public enum  AcademicUnit{
    BACHELOR_DEGREE
}


