package web.servlet;

public enum FacultyType {
    IT, BUSINESS_ADMINISTRATION, THEOLOGY
}
