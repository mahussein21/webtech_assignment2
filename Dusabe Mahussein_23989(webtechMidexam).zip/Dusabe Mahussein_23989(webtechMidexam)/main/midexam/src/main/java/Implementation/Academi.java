package Implementation;
import Dao.AcademicUnitDAO;
import Model.AcademicUnit;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public class Academi implements AcademicUnitDAO{
    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public AcademicUnit save(AcademicUnit academicUnit) {
        if (academicUnit.getAcademic_id() == null) {
            entityManager.persist(academicUnit);
            return academicUnit;
        } else {
            return entityManager.merge(academicUnit);
        }
    }

    @Override
    public Optional<AcademicUnit> findById(UUID academicId) {
        return Optional.ofNullable(entityManager.find(AcademicUnit.class, academicId));
    }

    @Override
    public List<AcademicUnit> findAll() {
        return entityManager.createQuery("from Implementation", AcademicUnit.class).getResultList();
    }

    @Override
    public void deleteById(UUID academicId) {
        AcademicUnit academicUnit = entityManager.find(AcademicUnit.class, academicId);
        if (academicUnit != null) {
            entityManager.remove(academicUnit);
        }
    }
}
