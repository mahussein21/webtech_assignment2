package Implementation;


import Dao.CourseDefinitionDao;
import Model.CourseDefinition;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import java.util.List;
import java.util.UUID;

public class CourseDefinitionDaoImpl implements CourseDefinitionDao {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public CourseDefinition save(CourseDefinition courseDefinition) {
        entityManager.persist(courseDefinition);
        return courseDefinition;
    }

    @Override
    public void update(CourseDefinition courseDefinition) {
        entityManager.merge(courseDefinition);
    }

    @Override
    public void delete(CourseDefinition courseDefinition) {
        entityManager.remove(courseDefinition);
    }

    @Override
    public CourseDefinition findById(UUID id) {
        return entityManager.find(CourseDefinition.class, id);
    }

    @Override
    public List<CourseDefinition> findAll() {
        return entityManager.createQuery("SELECT p FROM CourseDefinition p", CourseDefinition.class).getResultList();
    }
}
