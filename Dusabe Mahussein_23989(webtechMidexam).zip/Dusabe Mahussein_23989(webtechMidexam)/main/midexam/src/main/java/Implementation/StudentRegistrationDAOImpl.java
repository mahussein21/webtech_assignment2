package Implementation;

import Dao.StudentRegistrationDAO;
import Model.StudentRegistration;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
public class StudentRegistrationDAOImpl implements StudentRegistrationDAO {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public StudentRegistration insertStudentRegistration(StudentRegistration studentRegistration) {
        entityManager.persist(studentRegistration);
        return studentRegistration;
    }

    @Override
    public Optional<StudentRegistration> findStudentRegistrationById(UUID registrationId) {
        return Optional.ofNullable(entityManager.find(StudentRegistration.class, registrationId));
    }

    @Override
    public List<StudentRegistration> findAllStudentRegistrations() {
        return entityManager.createQuery("SELECT sr FROM StudentRegistration sr", StudentRegistration.class).getResultList();
    }

    @Override
    public StudentRegistration updateStudentRegistration(StudentRegistration studentRegistration) {
        return entityManager.merge(studentRegistration);
    }

    @Override
    public void deleteStudentRegistrationById(UUID registrationId) {
        StudentRegistration studentRegistration = entityManager.find(StudentRegistration.class, registrationId);
        if (studentRegistration != null) {
            entityManager.remove(studentRegistration);
        }
    }
}
