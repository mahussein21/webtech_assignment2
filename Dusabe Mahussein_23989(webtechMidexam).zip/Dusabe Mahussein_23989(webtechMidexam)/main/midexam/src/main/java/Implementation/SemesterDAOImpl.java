package Implementation;

import Dao.SemesterDAO;
import Model.Semester;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import java.util.List;
import java.util.Optional;
import java.util.UUID;


public class SemesterDAOImpl implements SemesterDAO {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public Semester insertSemester(Semester semester) {
        entityManager.persist(semester);
        return semester;
    }

    @Override
    public Optional<Semester> findSemesterById(UUID semesterId) {
        return Optional.ofNullable(entityManager.find(Semester.class, semesterId));
    }

    @Override
    public List<Semester> findAllSemesters() {
        return entityManager.createQuery("from Semester", Semester.class).getResultList();
    }

    @Override
    public Semester updateSemester(Semester semester) {
        return entityManager.merge(semester);
    }

    @Override
    public void deleteSemesterById(UUID semesterId) {
        Semester semester = entityManager.find(Semester.class, semesterId);
        if (semester != null) {
            entityManager.remove(semester);
        }
    }
}
