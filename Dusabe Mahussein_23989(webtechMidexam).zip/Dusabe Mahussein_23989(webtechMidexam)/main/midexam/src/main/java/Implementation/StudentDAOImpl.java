package Implementation;


import Dao.StudentDAO;
import Model.Student;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public class StudentDAOImpl implements StudentDAO {
    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public Student insertStudent(Student student) {
        entityManager.persist(student);
        return student;
    }

    @Override
    public Optional<Student> findStudentById(UUID studentId) {
        return Optional.ofNullable(entityManager.find(Student.class, studentId));
    }

    @Override
    public List<Student> findAllStudents() {
        return entityManager.createQuery("SELECT s FROM Student s", Student.class).getResultList();
    }

    @Override
    public Student updateStudent(Student student) {
        return entityManager.merge(student);
    }

    @Override
    public void deleteStudentById(UUID studentId) {
        Student student = entityManager.find(Student.class, studentId);
        if (student != null) {
            entityManager.remove(student);
        }
    }
}
