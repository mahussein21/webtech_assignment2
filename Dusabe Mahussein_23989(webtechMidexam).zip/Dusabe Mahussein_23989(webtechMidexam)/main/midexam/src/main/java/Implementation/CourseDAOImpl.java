package Implementation;

import Dao.CourseDAO;
import Model.Course;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public class CourseDAOImpl implements CourseDAO {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public Course insert(Course course) {
        entityManager.persist(course);
        return course;
    }

    @Override
    public Optional<Course> searchById(UUID courseId) {
        Course course = entityManager.find(Course.class, courseId);
        return course != null ? Optional.of(course) : Optional.empty();
    }

    @Override
    public List<Course> searchAll() {
        return entityManager.createQuery("SELECT c FROM Course c", Course.class).getResultList();
    }

    @Override
    public Course update(Course course) {
        return entityManager.merge(course);
    }

    @Override
    public void deleteById(UUID courseId) {
        Course course = entityManager.find(Course.class, courseId);
        if (course != null) {
            entityManager.remove(course);
        }
    }
}
