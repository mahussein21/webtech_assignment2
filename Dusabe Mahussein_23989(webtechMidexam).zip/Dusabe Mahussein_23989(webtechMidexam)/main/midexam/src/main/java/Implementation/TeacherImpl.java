package Implementation;

import Dao.TeacherDAO;
import Model.ATeacher;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
public class TeacherImpl implements TeacherDAO {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public ATeacher insertStudentRegistration(ATeacher studentRegistration) {
        entityManager.persist(studentRegistration);
        return studentRegistration;
    }

    @Override
    public Optional<ATeacher> findStudentRegistrationById(UUID registrationId) {
        return Optional.ofNullable(entityManager.find(ATeacher.class, registrationId));
    }

    @Override
    public List<ATeacher> findAllStudentRegistrations() {
        return entityManager.createQuery("SELECT sr FROM StudentRegistration sr", ATeacher.class).getResultList();
    }

    @Override
    public ATeacher updateStudentRegistration(ATeacher studentRegistration) {
        return entityManager.merge(studentRegistration);
    }

    @Override
    public void deleteStudentRegistrationById(UUID registrationId) {
        ATeacher studentRegistration = entityManager.find(ATeacher.class, registrationId);
        if (studentRegistration != null) {
            entityManager.remove(studentRegistration);
        }
    }

    @Override
    public ATeacher insertStudent(ATeacher teacher) {
        return null;
    }

    @Override
    public Optional<ATeacher> findStudentById(UUID teacherId) {
        return Optional.empty();
    }

    @Override
    public List<ATeacher> findAllStudents() {
        return null;
    }

    @Override
    public ATeacher updateStudent(ATeacher teacher) {
        return null;
    }

    @Override
    public void deleteStudentById(UUID teacherId) {

    }
}
