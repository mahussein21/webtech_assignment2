package Dao;

import Model.Semester;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface SemesterDAO {

    Semester insertSemester(Semester semester);

    Optional<Semester> findSemesterById(UUID semesterId);

    List<Semester> findAllSemesters();

    Semester updateSemester(Semester semester);

    void deleteSemesterById(UUID semesterId);
}

