package Dao;
import Model.Course;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface CourseDAO {
    Course insert(Course course);
    Optional<Course> searchById(UUID courseId);
    List<Course> searchAll();
    Course update(Course course);
    void deleteById(UUID courseId);
}
