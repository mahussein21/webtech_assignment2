package Dao;


import Model.ATeacher;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface TeacherDAO {

    ATeacher insertStudent(ATeacher teacher);

    Optional<ATeacher> findStudentById(UUID teacherId);

    List<ATeacher> findAllStudents();

    ATeacher updateStudent(ATeacher teacher);

    void deleteStudentById(UUID teacherId);
}
