package Dao;

import Model.CourseDefinition;
import java.util.List;
import java.util.UUID;

public interface CourseDefinitionDao {

    CourseDefinition save(CourseDefinition courseDefinition);

    void update(CourseDefinition courseDefinition);

    void delete(CourseDefinition courseDefinition);

    CourseDefinition findById(UUID id);

    List<CourseDefinition> findAll();
}
