
package Dao;

import Model.AcademicUnit;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

    public interface AcademicUnitDAO {

        AcademicUnit save(AcademicUnit academicUnit); // Create or update an academic unit

        Optional<AcademicUnit> findById(UUID academicId); // Retrieve an academic unit by ID

        List<AcademicUnit> findAll(); // List all academic units

        void deleteById(UUID academicId); // Delete an academic unit by ID
    }


