package Dao;


import Model.Student;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface StudentDAO {

    Student insertStudent(Student student);

    Optional<Student> findStudentById(UUID studentId);

    List<Student> findAllStudents();

    Student updateStudent(Student student);

    void deleteStudentById(UUID studentId);
}
