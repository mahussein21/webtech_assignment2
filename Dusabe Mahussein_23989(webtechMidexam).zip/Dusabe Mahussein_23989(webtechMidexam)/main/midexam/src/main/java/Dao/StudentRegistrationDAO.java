package Dao;

import Model.StudentRegistration;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface StudentRegistrationDAO {

    StudentRegistration insertStudentRegistration(StudentRegistration studentRegistration);

    Optional<StudentRegistration> findStudentRegistrationById(UUID registrationId);

    List<StudentRegistration> findAllStudentRegistrations();

    StudentRegistration updateStudentRegistration(StudentRegistration studentRegistration);

    void deleteStudentRegistrationById(UUID registrationId);
}
