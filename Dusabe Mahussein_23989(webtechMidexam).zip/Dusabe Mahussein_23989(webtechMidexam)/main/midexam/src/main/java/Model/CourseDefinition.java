package Model;

import jakarta.persistence.*;

import java.util.UUID;

@Entity
@Table(name = "course_definition")

public class CourseDefinition {
    @Id
    @GeneratedValue
    private UUID course_definition_id;

    private String course_definition_code;
    private String course_definition_description;

    @ManyToOne
    @JoinColumn(name = "course_id", referencedColumnName = "course_id")
    private Course course;

    public CourseDefinition() {
    }

    public CourseDefinition(Course course) {
        this.course = course;
    }

    public CourseDefinition(UUID course_definition_id, String course_definition_code, String course_definition_description, Course course) {
        this.course_definition_id = course_definition_id;
        this.course_definition_code = course_definition_code;
        this.course_definition_description = course_definition_description;
        this.course = course;
    }

    public UUID getCourse_definition_id() {
        return course_definition_id;
    }

    public void setCourse_definition_id(UUID course_definition_id) {
        this.course_definition_id = course_definition_id;
    }

    public String getCourse_definition_code() {
        return course_definition_code;
    }

    public void setCourse_definition_code(String course_definition_code) {
        this.course_definition_code = course_definition_code;
    }

    public String getCourse_definition_description() {
        return course_definition_description;
    }

    public void setCourse_definition_description(String course_definition_description) {
        this.course_definition_description = course_definition_description;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }
}
