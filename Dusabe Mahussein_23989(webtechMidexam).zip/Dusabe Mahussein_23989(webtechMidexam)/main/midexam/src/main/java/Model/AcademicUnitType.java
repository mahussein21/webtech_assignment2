package Model;

public enum AcademicUnitType {
    BACHELOR_DEGREE
}
public enum FacultyType {
    IT, BUSINESS_ADMINISTRATION, THEOLOGY
}

public enum DepartmentType {
    NETWORKING, SOFTWARE_ENGINEERING, INFORMATION_MANAGEMENT
}

