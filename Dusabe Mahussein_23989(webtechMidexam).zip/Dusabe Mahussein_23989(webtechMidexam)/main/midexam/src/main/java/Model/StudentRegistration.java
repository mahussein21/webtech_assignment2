package Model;

import jakarta.persistence.*;

import java.security.Timestamp;
import java.util.UUID;


@Entity
@Table(name = "studentRegistration")

public class StudentRegistration {
    @Id
    @GeneratedValue
    private UUID registration_id;

    private String registration_code;
    private Timestamp registration_date;

    @ManyToOne
    @JoinColumn(name = "student_id", referencedColumnName = "student_id")
    private Student student;

    @ManyToOne
    @JoinColumn(name = "semester_id", referencedColumnName = "semester_id")
    private Semester semester;

    @ManyToOne
    @JoinColumn(name = "department_id", referencedColumnName = "academic_id")
    private AcademicUnit department;

    public StudentRegistration() {
    }

    public StudentRegistration(AcademicUnit department) {
        this.department = department;
    }

    public StudentRegistration(UUID registration_id, String registration_code, Timestamp registration_date, Student student, Semester semester, AcademicUnit department) {
        this.registration_id = registration_id;
        this.registration_code = registration_code;
        this.registration_date = registration_date;
        this.student = student;
        this.semester = semester;
        this.department = department;
    }

    public UUID getRegistration_id() {
        return registration_id;
    }

    public void setRegistration_id(UUID registration_id) {
        this.registration_id = registration_id;
    }

    public String getRegistration_code() {
        return registration_code;
    }

    public void setRegistration_code(String registration_code) {
        this.registration_code = registration_code;
    }

    public Timestamp getRegistration_date() {
        return registration_date;
    }

    public void setRegistration_date(Timestamp registration_date) {
        this.registration_date = registration_date;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public Semester getSemester() {
        return semester;
    }

    public void setSemester(Semester semester) {
        this.semester = semester;
    }

    public AcademicUnit getDepartment() {
        return department;
    }

    public void setDepartment(AcademicUnit department) {
        this.department = department;
    }
}
