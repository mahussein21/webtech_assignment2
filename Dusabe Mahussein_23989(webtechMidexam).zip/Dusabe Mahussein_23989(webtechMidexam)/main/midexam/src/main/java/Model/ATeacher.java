package Model;

import jakarta.persistence.*;

import java.util.UUID;

@Entity
@Table(name = "teacher")

public class ATeacher {
    @Id
    @GeneratedValue
    private UUID teacher_id;

    private String first_name;
    private String last_name;
    private String qualification;

    @ManyToOne
    @JoinColumn(name = "course_id", referencedColumnName = "course_id")
    private Course course;

    public Teacher() {
    }

    public Teacher(Course course) {
        this.course = course;
    }

    public Teacher(UUID teacher_id, String first_name, String last_name, String qualification, Course course) {
        this.teacher_id = teacher_id;
        this.first_name = first_name;
        this.last_name = last_name;
        this.qualification = qualification;
        this.course = course;
    }

    public UUID getTeacher_id() {
        return teacher_id;
    }

    public void setTeacher_id(UUID teacher_id) {
        this.teacher_id = teacher_id;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }
}
