package Model;


import jakarta.persistence.*;

import java.util.UUID;

@Entity
@Table(name = "academic_unit")

public class AcademicUnit {
    @Id
    @GeneratedValue
    private UUID academic_id;

    private String academic_code;
    private String academic_name;

    @Enumerated(EnumType.STRING)
    private AcademicUnitType type;

    @ManyToOne
    @JoinColumn(name = "parent_id", referencedColumnName = "academic_id")
    private AcademicUnit parent;

    public AcademicUnit() {
    }

    public AcademicUnit(String academic_code) {
        this.academic_code = academic_code;
    }

    public AcademicUnit(UUID academic_id, String academic_code, String academic_name, AcademicUnitType type, AcademicUnit parent) {
        this.academic_id = academic_id;
        this.academic_code = academic_code;
        this.academic_name = academic_name;
        this.type = type;
        this.parent = parent;
    }

    public UUID getAcademic_id() {
        return academic_id;
    }

    public void setAcademic_id(UUID academic_id) {
        this.academic_id = academic_id;
    }

    public String getAcademic_code() {
        return academic_code;
    }

    public void setAcademic_code(String academic_code) {
        this.academic_code = academic_code;
    }

    public String getAcademic_name() {
        return academic_name;
    }

    public void setAcademic_name(String academic_name) {
        this.academic_name = academic_name;
    }

    public AcademicUnitType getType() {
        return type;
    }

    public void setType(AcademicUnitType type) {
        this.type = type;
    }

    public AcademicUnit getParent() {
        return parent;
    }

    public void setParent(AcademicUnit parent) {
        this.parent = parent;
    }
}
