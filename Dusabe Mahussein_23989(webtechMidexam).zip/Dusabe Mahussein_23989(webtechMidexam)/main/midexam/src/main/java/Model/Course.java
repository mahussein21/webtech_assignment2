package Model;

import jakarta.persistence.*;

import java.util.UUID;

@Entity
@Table(name = "Course")

public class Course {
    @Id
    @GeneratedValue
    private UUID course_id;

    private String course_code;
    private String course_name;

    @ManyToOne
    @JoinColumn(name = "semester_id", referencedColumnName = "semester_id")
    private Semester semester;

    @ManyToOne
    @JoinColumn(name = "department_id", referencedColumnName = "academic_id") // Assuming academic_id is the foreign key in AcademicUnit
    private AcademicUnit department;

    public Course() {
    }

    public Course(String course_code) {
        this.course_code = course_code;
    }

    public Course(UUID course_id, String course_code, String course_name, Semester semester, AcademicUnit department) {
        this.course_id = course_id;
        this.course_code = course_code;
        this.course_name = course_name;
        this.semester = semester;
        this.department = department;
    }

    public UUID getCourse_id() {
        return course_id;
    }

    public void setCourse_id(UUID course_id) {
        this.course_id = course_id;
    }

    public String getCourse_code() {
        return course_code;
    }

    public void setCourse_code(String course_code) {
        this.course_code = course_code;
    }

    public String getCourse_name() {
        return course_name;
    }

    public void setCourse_name(String course_name) {
        this.course_name = course_name;
    }

    public Semester getSemester() {
        return semester;
    }

    public void setSemester(Semester semester) {
        this.semester = semester;
    }

    public AcademicUnit getDepartment() {
        return department;
    }

    public void setDepartment(AcademicUnit department) {
        this.department = department;
    }
}
