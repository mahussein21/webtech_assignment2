public class Login {
    private String user_name;
    private String passWord;

    public Login() {
    }

    public Login(String user_name, String passWord) {
        this.user_name = user_name;
        this.passWord = passWord;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getPassWord() {
        return passWord;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }
}
